/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 * Esta es una abstraccion de la clase TipoCentroAtencion
 * @author Josue Brenes, Paola Lopez, Alejandra Merino
 */
public class TipoCentroAtencion {
  private String tipoCentro;

  //Metodos accesores
  public String getTipoCentro() {
    return tipoCentro;
  }

  public void setTipoCentro(String tipoCentro) {
    this.tipoCentro = tipoCentro;
  }
}
